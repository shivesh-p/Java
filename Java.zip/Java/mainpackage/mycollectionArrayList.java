package mainpackage;

import java.io.*;
import java.lang.*;
import java.util.ArrayList;
import java.util.Iterator;
public class mycollectionArrayList {
   static ArrayList<Integer> ls=new ArrayList<Integer>();
    public static void main(String[] args)throws IOException{
        
         ls.add(1);
         ls.add(2);
         ls.add(4);
         ls.add(7); //find this number using binary search
         ls.add(8);
         ls.add(9);
         Iterator tr=ls.iterator();
         while(tr.hasNext())
         System.out.println(tr.next());
         
         System.out.println("Do you want to perform a BinarySearch?If Yes then input Yes and Enter the element");
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
         String r=br.readLine();
         BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
         int t=Integer.parseInt(br1.readLine());
         mycollectionArrayList mlc=new mycollectionArrayList();
         if((r.equals("yes")))
            mlc.BinarySearch(t);
}
static void BinarySearch(int ele){
         boolean Isfound=true;
         int high=ls.size()-1;
         int low=0;
         int NumberSearch=ele;
         int mid;
 while (Isfound){
     mid= low+(high-low)/2;
     if(ls.get(mid)==NumberSearch)
     {System.out.println("we found number at index:"+ mid+" and at position "+(mid+1));
        break;
     }
     if(ls.get(mid)<NumberSearch)
         low=mid;
     if(ls.get(mid)>NumberSearch)
         high=mid;
      
 }
    }
}
