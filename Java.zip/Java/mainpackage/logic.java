package mainpackage;

public class logic {
 /*
  *  logic operation ( >,>=, < , <=, ==, !=)
  *  Logic gate (&&, ||, !)
  */
	public static void main(String[] args){
		// And (only t and t=true other false)
		//, Or  only  f or f=false other true
		//, Not  Not(True)=false , Not(false)=true
		// truth table
		System.out.println(!(3<1) );
	}
}
