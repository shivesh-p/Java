package mainpackage;

import java.util.HashMap;
import java.util.Map;

public class mycollectionHashMap {
	public static void main(String[] args){
		HashMap<Integer, String> map=new HashMap<Integer, String>();
		map.put(1,"shivesh1");
		map.put(4,"shivesh4");
		map.put(5555,"shivesh5555");
		System.err.println(map.get(1));
		for(Map.Entry m:map.entrySet()){
			System.err.println("key:"+ m.getKey() + ",value:"+ m.getValue());
		}
		map.put(1,"shivesh 1 pandey");
		System.err.println(map.get(1));
		map.remove(1);
	}
}
