package mainpackage;

public class var {

	
	public static void main(String[] args)
	{
		String name= "Shivesh Pandey";
		int age=20;
		double Salary=3500.7;
		char Gender='m';
	 
	 
		System.out.println("name:"+ name);
		System.out.println("age:"+age);
		System.out.println("Salary:"+ Salary);
		System.out.println("Gender:"+ Gender);
	}
}
