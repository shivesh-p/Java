package mainpackage;

public class break_continue {
public static void main(String[] args){
        
        for(int i=1;i<100;i=i+1)
        { //block of code
        
             System.out.println(  i);
    
            if(i ==50)
            {
                 System.out.println("count:"+ i);
                 System.out.println("count is printed");
                break;
            }
    
        }
        int i=1;
        for(i=0;i<=9;i++)
        {
            if((i%2)!=0)
                continue;
                System.out.println(i);
        }
}
}
