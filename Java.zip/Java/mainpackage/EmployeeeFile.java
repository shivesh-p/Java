package mainpackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class EmployeeeFile {

	public static void main(String[] args) {
	 
	 
		Employeee emp=new Employeee();
		emp.name="Shivesh";
		emp.age=19;
		try{
		FileOutputStream fo=new FileOutputStream("Employeee.txt");
		ObjectOutputStream out=new ObjectOutputStream(fo);
		out.writeObject(emp);
		out.close();
		fo.close();
		}catch(Exception ex){}
		 
		Employeee emp1=null;
		try{
			FileInputStream f1=new FileInputStream("Employeee.txt");
			ObjectInputStream in=new ObjectInputStream(f1);
			emp1=(Employeee)in.readObject();
			in.close();
			f1.close();
			System.out.println(emp.name);
			System.out.println(emp.age);
			}catch(Exception ex){}
	}
}
