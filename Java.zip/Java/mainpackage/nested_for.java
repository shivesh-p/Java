package mainpackage;

public class nested_for {
	public static void main(String[] args){
		 
	 for (int i=0;i<10;i++)
	 {
	 System.out.println("*");
	  for(int j=i;j>=0;j--)
	   System.out.print("-");	
	 }
	 
	}
}
