package mainpackage;

public enum Gender {
Male,
Female
}
