package mainpackage;

public class javamysql {
	 public static void main(String argv[]) {
		 
	 }
}
