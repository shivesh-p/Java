package mainpackage;

public class simple_if {

	public static void main(String[] args){
		
		for(int i=1;i<100;i=i+1)
		{ //block of code
		//System.out.println("count:"+ i);
		if( i % 4==0)
			System.out.println("mode by 4 is:"+ i);
		}
		 
	}
}
