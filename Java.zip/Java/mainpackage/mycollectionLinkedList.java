package mainpackage;
import java.util.*;
import java.util.Iterator;
import java.util.LinkedList;

public class mycollectionLinkedList {

    public static void main(String[] args){
    LinkedList<String> ll=new LinkedList<String>();
    
    ll.add("Shivesh Pandey");
    ll.add("Nirmala Pandey");
    ll.add("Ajay Pandey");
    
    Iterator<String> itr=ll.iterator();
    
    while(itr.hasNext())
        System.out.println(itr.next());
    
     ll.remove("Shivesh Pandey");
        Iterator<String> itr1=ll.iterator();
    while(itr1.hasNext())
        System.out.println(itr1.next());


    }
}
