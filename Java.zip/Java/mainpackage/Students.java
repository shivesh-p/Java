package mainpackage;

public class Students {
String FirstName;
Gender gender;
public Students(String FirstName, Gender gender){
	this.gender=gender;
	this.FirstName=FirstName;
}
}
