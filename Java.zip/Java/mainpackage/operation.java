package mainpackage;

public interface operation {
 int sum(int n1, int n2);
 int sub(int n1, int n2);
 double div(int n1, int n2);
 int mul(int n1, int n2);
}
