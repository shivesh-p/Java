package mainpackage;

import java.sql.Date;

public class Owners {
String FarstName;
String LastName;
Date DOB;
}
